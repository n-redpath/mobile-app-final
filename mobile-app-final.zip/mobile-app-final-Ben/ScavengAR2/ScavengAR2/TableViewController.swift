//
//  TableViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//
import UIKit
import ARKit

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var tableView: UITableView!
    
    var names = ["joseCuerv", "salt", "wine"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setUpTableView()
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        push to favorite view on tap
        let cv = CameraViewController()
        cv.imageName = names[indexPath.row]
        navigationController?.pushViewController(cv, animated: true)
        print("pressed")
    }
    
    func setUpTableView(){
//        set up table view
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        populate rows
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel!.text = names[indexPath.row]
        return cell
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
//      reloads table view every time it is called so that favorites are updated
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    
    
}



