//
//  CameraViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//

import UIKit
import ARKit
import SceneKit
import Foundation

class CameraViewController: UIViewController, ARSCNViewDelegate {

//    @IBOutlet weak var scnView: ARSCNView!
    let config = ARWorldTrackingConfiguration()
    
    var imageName: String!
    
    var arView: ARSCNView {
         return self.view as! ARSCNView
      }
      override func loadView() {
        self.view = ARSCNView(frame: .zero)
      }
    
    
    override func viewDidLoad() {
            print("in camera view")
        
        super.viewDidLoad()
        
        _ = self.view
//        scnV iew.session.run(config)

        // Set the view's delegate
        arView.delegate = self
        
        // Show statistics such as fps and timing information
        arView.showsStatistics = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)!
        
        configuration.detectionImages = referenceImages

        // Run the view's session
        arView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        arView.session.pause()
    }

    // MARK: - ARSCNViewDelegate
    
/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    
//    The following code was learned from the video: https://www.youtube.com/watch?v=J35KGP4oe98
     func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
                guard let imageAnchor = anchor as? ARImageAnchor else {return}
    
        //       this happens when the image has been found!!
                let referenceImage = imageAnchor.referenceImage
                let plane = SCNPlane(width: referenceImage.physicalSize.width, height: referenceImage.physicalSize.height)
                plane.firstMaterial?.diffuse.contents = UIColor.blue
                let planeNode = SCNNode(geometry: plane)
                planeNode.opacity = 0.25
                planeNode.eulerAngles.x = -Float.pi/2
                node.addChildNode(planeNode)
//        get name of file.
                print("found...")
                print(imageAnchor.referenceImage.name)
        if (imageAnchor.referenceImage.name == imageName){
            print("same!")
            
            DispatchQueue.main.async {
                   // Your UI Updation here
                let alert = UIAlertController(title: "Congratulations!", message: "you found \(self.imageName)", preferredStyle: .alert)

                
                alert.addAction(UIAlertAction(title: "Find the next item", style: .cancel, handler:nil))
                
                self.present(alert, animated: true)
                
//                This next part doesnt work yet (trying to navigate back programmatically.)
                
//                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                let newViewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
//                        self.present(newViewController, animated: true, completion: nil)
               }
            
            
        }
        
//        if its the same as the name you are searching for -- points!
    
            }
    
    
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}
