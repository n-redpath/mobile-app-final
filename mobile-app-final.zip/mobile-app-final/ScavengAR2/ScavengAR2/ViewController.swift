//
//  ViewController.swift
//  ScavengAR2
//
//  Created by Reid Watson on 12/9/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//

import UIKit

public var playerLevel = 1
//
//var levelOne = ["stop", "oneWay", "deadEnd", "doNotEnter", "speedLimit"]
//var levelTwo = ["ketchup", "mustard", "mayo", "sriracha", "ranch"]
//var levelThree = ["laCroix", "joseCuervo", "coke", "titos", "corona"]
//var levelFour = ["oreo", "dominos", "jif", "cheetos", "takis"]
//var levelFive = ["mbw", "minicooper", "volkswagen", "chevy", "mercedes"]
//var levelSix = ["crayola", "ducktape", "modgepodge", "elmers", "playdoh"]


class ViewController: UIViewController {
//    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        print("viewDidLoad")
        super.viewDidLoad()
//         Do any additional setup after loading the view.
//        defaults.set(levelOne, forKey: "levelOne")
//                defaults.set(levelTwo, forKey: "levelTwo")
//        defaults.set(levelThree, forKey: "levelThree")
//        defaults.set(levelFour, forKey: "levelFour")
//        defaults.set(levelFive, forKey: "levelFive")
//        defaults.set(levelSix, forKey: "levelSix")
    }


}

