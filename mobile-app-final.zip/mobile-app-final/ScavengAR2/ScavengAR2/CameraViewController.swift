//
//  CameraViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//

import UIKit
import ARKit
import SceneKit
import Foundation

class CameraViewController: UIViewController, ARSCNViewDelegate {
    
    let defaults = UserDefaults.standard

    //    @IBOutlet weak var scnView: ARSCNView!
    let config = ARWorldTrackingConfiguration()
    
    var imageName: String!
    var rowIndex: Int!
    var level: Int!
    
    var arView: ARSCNView {
         return self.view as! ARSCNView
      }
      override func loadView() {
        self.view = ARSCNView(frame: .zero)
      }
    
    
    override func viewDidLoad() {
            print("in camera view")
        
        super.viewDidLoad()
        
        _ = self.view
//        scnV iew.session.run(config)

        // Set the view's delegate
        arView.delegate = self
        
        // Show statistics such as fps and timing information
        arView.showsStatistics = true
        self.arView.autoenablesDefaultLighting = true
        
        let scene = SCNScene()
        self.arView.scene = scene
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)!
        
        configuration.detectionImages = referenceImages

        // Run the view's session
        arView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        arView.session.pause()
    }

    // MARK: - ARSCNViewDelegate
    
/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    
//    The following code was learned from the video: https://www.youtube.com/watch?v=J35KGP4oe98
     func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
                guard let imageAnchor = anchor as? ARImageAnchor else {return}
    
        //       this happens when the image has been found!!
                let referenceImage = imageAnchor.referenceImage
                let plane = SCNPlane(width: referenceImage.physicalSize.width, height: referenceImage.physicalSize.height)
                plane.firstMaterial?.diffuse.contents = UIColor.blue
                let planeNode = SCNNode(geometry: plane)
                planeNode.opacity = 0.25
                planeNode.eulerAngles.x = -Float.pi/2
                node.addChildNode(planeNode)
//        get name of file.
                print("found...")
                print(imageAnchor.referenceImage.name)
        if (imageAnchor.referenceImage.name == imageName){
            print("same!")
            updateTableView(item: imageName)

            DispatchQueue.main.async {
                   // Your UI Updation here
                let alert = UIAlertController(title: "Congratulations!", message: "you found \(self.imageName)", preferredStyle: .alert)

                
                alert.addAction(UIAlertAction(title: "Find the next item", style: .default, handler: {action in
                    
                    
                    
                    _ = self.navigationController?.popToRootViewController(animated: true)
//                    TableViewController().viewWillAppear(true)

                }))
                
                self.present(alert, animated: true)
                
               }
            
            
        }

    
            }
    func updateTableView(item: String) {
          
           switch (playerLevel) {
          
           case(1):
               var arr = (defaults.array(forKey: "levelOne") ?? []) as [String]
               if let index = arr.firstIndex(where: { (item) -> Bool in
                   print("Contains")
                   return true}) {
                   arr.remove(at: index)
                   defaults.set(arr, forKey: "levelOne")
                for str in arr {
                    print(str)
                }
               }
           case (2):
               var arr = (defaults.array(forKey: "levelTwo") ?? []) as [String]
               if let index = arr.firstIndex(where: { (item) -> Bool in
                   print("Contains")
                   return true}) {
                   arr.remove(at: index)
               }
           case (3):
               var arr = (defaults.array(forKey: "levelThree") ?? []) as [String]
               if let index = arr.firstIndex(where: { (item) -> Bool in
                   print("Contains")
                   return true}) {
                   arr.remove(at: index)
               }
           default:
               break
          
           }
          
       }

    
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}
