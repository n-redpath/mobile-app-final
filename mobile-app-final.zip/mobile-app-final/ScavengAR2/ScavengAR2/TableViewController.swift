//
//  TableViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//
import UIKit
import ARKit

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var tableView: UITableView!
    
    
    var items: [String] = []
    let defaults = UserDefaults.standard
    var level: Int = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setUpTableView()
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        
        level = defaults.integer(forKey: "Level")
        print(defaults.integer(forKey: "Level"))
        items = getLevel(level: level)
    }
    
    func getLevel(level: Int) -> [String]{
        switch (playerLevel) {
       
        case(1):
            return (defaults.array(forKey: "levelOne") ?? []) as [String]
        case(2):
            return (defaults.array(forKey: "levelTwo") ?? []) as [String]
        case(3):
            return (defaults.array(forKey: "levelThree") ?? []) as [String]
        case(4):
            return (defaults.array(forKey: "levelFour") ?? []) as [String]
        case(5):
            return (defaults.array(forKey: "levelFive") ?? []) as [String]
        case(6):
            return (defaults.array(forKey: "levelSix") ?? []) as [String]
        default:
            break
        }
        return []
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        push to favorite view on tap
        let cv = CameraViewController()
        
        cv.imageName = items[indexPath.row]
        cv.rowIndex = indexPath.row
        cv.level = level
        
        navigationController?.pushViewController(cv, animated: true)
        print("pressed")
    }
    
    func setUpTableView(){
//        set up table view
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        populate rows
        print("reloading cells")
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
    
            cell.textLabel!.text = items[indexPath.row]
        return cell
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
//      reloads table view every time it is called so that favorites are updated
        items = getLevel(level: level)
        super.viewWillAppear(animated)
        self.tableView.reloadData()
        print("view will appear")

    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.tableView.reloadData()
        print("view did appear")
    }
    
}



