//
//  LevelSelectViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//

import UIKit

class LevelSelectViewController: UIViewController {
    
    
    var currentLevel = 0
    
    var tView = TableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func levelOneButton(_ sender: Any) {
        currentLevel = 1
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
            
//        self.navigationController?.pushViewController(TableViewController(), animated: true)
        
        print(defaults.integer(forKey: "Level"))
    }
    
    
    @IBAction func levelTwoButton(_ sender: Any) {
        currentLevel = 2
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
        
        print(defaults.integer(forKey: "Level"))
        
    }
    
    
    @IBAction func levelThreeButton(_ sender: Any) {
        currentLevel = 3
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
        
//        navigationController?.pushViewController(tableView, animated: true)
        
        print(defaults.integer(forKey: "Level"))
    }
   
    
    @IBAction func levelFourButton(_ sender: Any) {
        currentLevel = 4
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
        
//        navigationController?.pushViewController(tableView, animated: true)
        
        print(defaults.integer(forKey: "Level"))
    }
    

    
    @IBAction func levelFiveButton(_ sender: Any) {
        currentLevel = 5
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
        
//        navigationController?.pushViewController(tableView, animated: true)
        
        print(defaults.integer(forKey: "Level"))
    }
    
    
    @IBAction func levelSixButton(_ sender: Any) {
        currentLevel = 6
        
        let defaults = UserDefaults.standard
        
        defaults.setValue(currentLevel, forKey: "Level")
        
//        navigationController?.pushViewController(tableView, animated: true)
        
        print(defaults.integer(forKey: "Level"))
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
