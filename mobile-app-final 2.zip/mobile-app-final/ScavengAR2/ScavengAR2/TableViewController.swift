//
//  TableViewController.swift
//  ScavengAR2
//
//  Created by Nina Redpath on 12/11/20.
//  Copyright © 2020 Reid Watson. All rights reserved.
//
import UIKit
import ARKit

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var tableView: UITableView!
    
    
    var names: [String] = []
    let defaults = UserDefaults.standard
    var level: Int = 0
    var levelOne = ["stop", "oneWay", "deadEnd", "doNotEnter", "speedLimit"]
    
    var levelTwo = ["ketchup", "mustard", "mayo", "sriracha", "ranch"]
    
    var levelThree = ["laCroix", "joseCuervo", "coke", "titos", "corona"]
    
    var levelFour = ["oreo", "dominos", "lays", "cheetos", "goldfish"]
    
    var levelFive = ["spotify", "fedex", "nike", "mastercard", "ups"]
    
    var levelSix = ["chevy", "mazda", "subaru", "ford", "jeep"]



    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setUpTableView()
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        level = defaults.integer(forKey: "Level")
        print(defaults.integer(forKey: "Level"))
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        push to favorite view on tap
        let cv = CameraViewController()
        cv.imageName = names[indexPath.row]
        navigationController?.pushViewController(cv, animated: true)
        print("pressed")
    }
    
    func setUpTableView(){
//        set up table view
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (level != 0){
            return 5
        }
        else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        populate rows
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        
        if (level == 1){
            cell.textLabel!.text = levelOne[indexPath.row]
        }
        else if (level == 2){
            cell.textLabel!.text = levelTwo[indexPath.row]
        }
        else if (level == 3){
            cell.textLabel!.text = levelThree[indexPath.row]
        }
        else if (level == 4){
            cell.textLabel!.text = levelFour[indexPath.row]
        }
        else if (level == 5){
            cell.textLabel!.text = levelFive[indexPath.row]
        }
        else if (level == 6){
            cell.textLabel!.text = levelSix[indexPath.row]
        }
        else {
            cell.textLabel!.text = "No Level Selected"
            cell.isUserInteractionEnabled = false;
        }
        
        return cell
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
//      reloads table view every time it is called so that favorites are updated
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    
    
}



